<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
  <div class="container">
    <img src="/frontend/images/New-Logo.png" style="height: 55px" alt="">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
      aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ms-auto justify-content-end">
        <li class="nav-item">
          <a class="nav-link" href="{{route('home-page')}}">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link"href="{{route('about-us')}}">About Us</a>
        </li>
        <li class="nav-item">
          <a class="nav-link hello22" href="{{route('product-page')}}">Product</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="{{route('check-authenticity')}}">Check Authenticity</a>
        </li>
      </ul>
    </div>
  </div>
</nav>