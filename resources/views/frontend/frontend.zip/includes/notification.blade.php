<div class="header_notification_warp d-flex align-items-center">
    <li>
        <a class="bell_notification_clicker" href="#"> <img src={{ asset('website/img/icon/bell.svg') }} alt="">
            <span>2</span>
        </a>

        <div class="Menu_NOtification_Wrap">
            <div class="notification_Header">
                <h4>Notifications</h4>
            </div>
            <div class="Notification_body">

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/2.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>Cool Marketing </h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/4.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>Awesome packages</h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/3.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>what a packages</h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/2.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>Cool Marketing </h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/4.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>Awesome packages</h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>

                <div class="single_notify d-flex align-items-center">
                    <div class="notify_thumb">
                        <a href="#"><img src={{ asset('website/img/staf/3.png') }} alt=""></a>
                    </div>
                    <div class="notify_content">
                        <a href="#">
                            <h5>what a packages</h5>
                        </a>
                        <p>Lorem ipsum dolor sit amet</p>
                    </div>
                </div>
            </div>
            <div class="nofity_footer">
                <div class="submit_button text-center pt_20">
                    <a href="#" class="btn_1">See More</a>
                </div>
            </div>
        </div>

    </li>
</div>
