<footer class="bg-dark text-light mt-5">
  <div class="container py-4">
    <div class="row">
      <div class="col-md-4">
        <h4>ABOUT</h4>
        <p>Bangladesh's only original Keto Green Coffee, produced by Elite Corporation and marketed by Dream Walkers,
          has been a concern due to fake products. To identify the genuine Keto Green Coffee, search the 6-digit
          secret number on the product's back and use the code to check authenticity. The website dwnauralsbd.com
          offers a QRcode to check the authenticity of Dream Walkers Keto Green Coffee.</p>
      </div>
      <div class="col-md-4">
        <h4>CATEGORIES</h4>
        <ul>
          <li>GREEN COFFEE</li>
          <li>KETO GREEN COFFEE</li>
          <li>NATURAL DIET </li>
          <li>PERFECT FIGURE </li>
        </ul>
      </div>
      <div class="col-md-4">
        <h4>QUICK LINKS</h4>
        <ul>
          <li>About Us</li>
          <li>Home</li>
          <li>Check_Authenticity</li>
          <li>Product</li>
        </ul>
      </div>
    </div>
  </div>
</footer>