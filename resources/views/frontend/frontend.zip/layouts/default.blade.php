<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from demo.dashboardpack.com/user-management-html/empty_page.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 May 2023 17:07:52 GMT -->

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    @include('frontend.includes.head')
    {{-- @livewireStyles --}}
</head>

    {{-- <section class="main_content dashboard_part large_header_bg"> --}}

        @include('frontend.includes.navbar')
        @include('frontend.includes.slider')

                        @yield('content')
    

        @include('frontend.includes.footer')

       @include('frontend.includes.scripts')
</body>

<!-- Mirrored from demo.dashboardpack.com/user-management-html/empty_page.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 08 May 2023 17:07:52 GMT -->

</html>
