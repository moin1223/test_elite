@extends('frontend.layouts.default')
<style>
  /* Mobile Styles */

@media screen and (max-width: 767px) {
    .container {
      padding-left: 15px;
      padding-right: 15px;
    }
    
    .col-md-6 {
      width: 100%;
      margin-bottom: 30px;
    }
    
    .img-responsive {
      width: 100%;
      height: auto;
    }
  }
  
  /* General Styles */
  
  #fh5co-about {
    padding: 80px 0;
  }
  
  .about-content {
    text-align: left;
  }
  
  .about-content .desc {
    margin-bottom: 30px;
  }
  
  .about-content h3 {
    font-size: 30px;
    line-height: 1.3;
    margin-bottom: 20px;
  }
  
  .about-content p {
    font-size: 16px;
    line-height: 1.6;
    color: #555555;
  }
  
  .about-content .about-us-text {
    font-weight: bold;
    color: #000000;
  }
  
  .red-about-us {
    color: red;
  }
  
  /* Image Styles */
  
  .img-responsive {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: transform 0.3s ease;
  }
  
  .img-responsive:hover {
    transform: scale(1.1);
  }
  
  .img-responsive:active {
    transform: scale(0.9);
  }
  
</style>
@section('content')
<div id="fh5co-about">
  <div class="container">
    <div class="about-content">
      <div class="row animate-box">
        <div class="col-md-6">
          <div class="desc">
            <h3>Company History</h3>
            <p>বাংলাদেশের একমাত্র অরিজিনাল কিটো গ্রীন কফি গত ৩ বছর ধরে উৎপাদন করছে <span class="about-us-text">Elite Corporation</span>  এবং বাজারজাতকরণ করছে<span class="about-us-text"> ড্রিম ওয়াকার্স।</span> বাজারে হাজারো নকল কিটো গ্রীন কফি সেবন করে অনেকে তাদের সমস্যার কথা আমাদের জানিয়েছেন। আর তাই আমরা প্রথমবারের মত ড্রিম ওয়াকার্স অরিজিনাল কিটো গ্রীন  কফি চেনার জন্য সিকিউরিটি কোডের ব্যবস্থা করেছি।আপনার হাতে থাকা কিটো গ্রীন কফিটি ১০০% ড্রিম ওয়াকার্সের বাজারজাতকরণ কিনা তা বুঝে নিতে পণ্যের পিছনে দেয়া <span class="about-us-text"> ৬ ডিজিটের </span> গোপন সংখ্যাটি আমাদের <span class="about-us-text"> Website </span> এর <span class="about-us-text"> Check Authenticity </span> অপশনে গিয়ে সার্চ করে বুঝে নিতে পারবেন। যদি আপনার হাতে থাকা কিটো গ্রীন কফির পিছনে সিকিউরিটি কোর্ড না থাকে তাহলে তা নকল বলে গণ্য হবে। একটি সিকিউরিটি কোড শুধু মাত্র <span class="about-us-text"> একবার </span>  ব্যবহার করা যাবে। পরবর্তীতে সিকিউরিটি কোড আবার ব্যবহার করলে মেয়াদ উত্তীর্ণ দেখাবে তারিখ এবং সময়সহ। ড্রিম ওয়ার্কার্সের আসল কিটো গ্রীন কফি চিনতে হলে <span class="about-us-text">QR</span>কোড স্কেন করলে সরাসরি আমাদের অফিসিয়াল ওয়েবসাইট <span class="about-us-text"> dwnauralsbd.com</span> এ নিয়ে যাবে। সেখানে সিকিউরিটি কোড বসিয়ে চেক করে নিবেন অরজিনাল আর নকল।  
<br> <span class= "red-about-us">বিঃ দ্রঃ আমাদের dwnaturalsbd.com ব্যতিত অন্য কোন ওয়েব সাইট নেই।</span></p>
          </div>
          
        </div>
        <div class="col-md-6">
          <img class="img-responsive" src="/frontend/images/Keto-Green-Coffee.png" alt="about">
        </div>
      </div>
    </div>
    
      </div>
    </div>
  </div>
</div>

@endsection