@extends('frontend.layouts.default')
<style>
      .hot{
      width: 50px;
      height: 20px;
      background-color: red;
      text-align: center;
      margin-top: 15px;
      border-radius: 5px;
      color: aliceblue;
      font-weight: bold;
      padding-bottom: 3px;
      font-size: small;
      margin-left: 5px;
    }
</style>
@section('content')
<div class="container mt-5">
  <div class="row">
  
    @foreach ($products as $product)
    <div class="col-md-4 mt-5">
      <div class="card">
        <p class="hot">HOT</p>
        <img src={{ $product->image }} class="card-img-top" alt="...">
        <div class="card-body">
          <p class="text-muted text-uppercase">{{$product->product_name}}</p>
          <h5 class="card-title text-uppercase">{{$product->product_name}}</h5>
          <p class="text-muted mt-2">{{$product->weight}}gm</p>
          <p class="text-warning"><del>{{$product->old_price}}tk</del> <span class="fs-4 bold">{{$product->new_price}}TK</span></p>
        </div>
      </div>
    </div>
    @endforeach
  </div>
</div>
  
    <!------------------------------------ end product---------------------------------- -->
@endsection