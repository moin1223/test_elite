<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href={{ asset('frontend/css/bootstrap/css/bootstrap.min.css') }} />
  <title>Responsive Navbar</title>

  <style>
    body {
      /* background-image: url('/frontend/images/Check-Authenticity-New.png');
      background-size: cover;
      background-repeat: no-repeat;
      min-height: 100vh; */
      background-color: aliceblue;
    }
    @media screen and (min-width: 800px) {
      .Elite-Corporation-logo{
      height: 100px;
      width: 100px;
      /* margin-top: 200px; */
      margin-right: 150px;
    }
    .Keto-Green-Coffee-Logo{
       height: 120px;
      width: 120px;
      /* margin-top: 200px; */
    }
    h3{
     margin-top: 100px;
    }


  }

    @media screen and (max-width: 800px) {
      .Elite-Corporation-logo{
      height: 100px;
      width: 100px;
      margin-top: 200px;
      margin-right: 150px;
    }
    .Keto-Green-Coffee-Logo{
        height: 120px;
      width: 120px;
      margin-top: 200px;
    }
    h3{
     margin-top: 100px;
    }


  }


    @media screen and (max-width: 400px) {
      .Elite-Corporation-logo{
      height: 70px;
      width: 100px;
      margin-top: 50px;
      margin-right: 50px;
    }
      .Keto-Green-Coffee-Logo{
        height: 100px;
        width: 100px;
        margin-top: 50px;
    }
      
}

.form-input{
  margin-left: 25%;
}
  </style>
</head>

<body>
    @include('frontend.includes.navbar')
  <div class="container mt-5">
    <div class="row">
      <div class="col-lg-8 offset-lg-2">
        <div class="text-center">
          <h3 class="title">আপনার প্রোডাক্টটি অরিজিনাল কিনা চেক করুন</h3>
          <!-- <p>আপনার হাতে থাকা কিটো গ্রীন কফির পিছনে দেয়া ৬ ডিজিটের সিকিউরিটি কোডটি এখানে তুলুন।</p> -->
            <form  method="POST" action="{{ route('check-code-authenticity') }}">
              @csrf
              <div class="mb-3">
                <div class="text-center">
                  <label for="formGroupExampleInput" class="form-label">আপনার হাতে থাকা কিটো গ্রীন কফির পিছনে দেয়া <br>৬ ডিজিটের সিকিউরিটি কোডটি এখানে তুলুন।</label>
                  <input type="text" name="product_code" class="form-control form-input w-50" id="formGroupExampleInput" placeholder="">
                </div>

              </div>
              <div class="row justify-content-center">
                <div class="col-auto">
                  <button type="submit" class="btn btn-primary">সাবমিট করুন</button>
                </div>
              </div>
            </form>
            <p class="mt-3">বিঃ দ্রঃ কোডটি শুধু মাত্র একবারই ব্যবহার করতে পারবেন,<br>কোডটি পূর্বে ব্যবহৃত হয়ে গেলে তা মেয়াদ উত্তীর্ণ দেখাবে।</p>
            @if (session('message'))
            <div class="alert alert-success message">
                {{ session('message') }}
                {{ session('codeExpireDate') }}            
            </div>
        @endif
            <img class="Elite-Corporation-logo" src="/frontend/images/Elite-Corporation-logo.png" alt="logo1">
            <img class="Keto-Green-Coffee-Logo" src="/frontend/images/20230715_215707 (1).png" alt="logo2">
        </div>
      </div>
    </div>
  </div>

  <script src="{{ asset('frontend/css/bootstrap/js/bootstrap.bundle.js') }}"></script>
</body>

</html>
